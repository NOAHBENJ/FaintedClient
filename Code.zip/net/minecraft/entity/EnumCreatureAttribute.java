package net.minecraft.entity;

public enum EnumCreatureAttribute
{
    UNDEFINED,
    UNDEAD,
    ARTHROPOD;
}
