package net.minecraft.nbt;

public class NBTException extends Exception
{
    public NBTException(String p_i45136_1_)
    {
        super(p_i45136_1_);
    }
}
