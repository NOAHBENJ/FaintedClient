package me.fainted.gui;

import java.awt.Color;

import org.lwjgl.input.Keyboard;
import org.lwjgl.input.Mouse;

import me.fainted.Fainted;
import me.fainted.module.Module;
import me.fainted.util.ColourUtil;
import me.fainted.util.Wrapper;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.FontRenderer;
import net.minecraft.client.gui.Gui;
import net.minecraft.client.gui.GuiIngame;
import net.minecraft.client.gui.ScaledResolution;

public class GuiIngameHook extends GuiIngame{

	private Minecraft mc = Minecraft.getMinecraft();
	private FontRenderer font = mc.fontRendererObj;
	
	public GuiIngameHook(Minecraft mcIn) {
		super(mcIn);
	}

	
	@Override
	public void renderGameOverlay(float partialTicks) {
		super.renderGameOverlay(partialTicks);
		if (!mc.gameSettings.showDebugInfo) {
		
			drawRect(2, 2, 95, 14, 0x80000000);
			Wrapper.fr.drawString("\247cFainted: ", 4, 4, 0x3300FF);
			Wrapper.fr.drawString("FPS: " + mc.getDebugFPS(), 50, 4, -1);
			
			renderArrayList();
		}
	}
	
	public void renderToggledBanner(String module) {
		ScaledResolution sr = new ScaledResolution(mc);
		
		Gui.drawRect(sr.getScaledWidth() - 100, sr.getScaledWidth() - 100, sr.getScaledWidth() - 4 - 29 - 29 - 29, sr.getScaledHeight() - 4 - 29 - 29 - 20, 0x90ffffff);
		font.drawString("W", 275, 275, 0xffffffff);
	}
	
	public void renderArrayList() {
		int yCount = 10;
		int index = 0;
		long x = 0;
		for(Module m : Fainted.instance.moduleManager.getModules()) {
			m.onRender();
			
			if (m.isToggled()) {
				Wrapper.fr.drawString(m.getName(), 5, yCount + 5, ColourUtil.rainbowEffect(index + x*2000000000L, 1.0F).getRGB());
				yCount += 10;
				index++;
				x++;
			}
		}
	}
	
}
