package me.fainted.alt;

public class AltLoginFromFile {

}
