package me.fainted.events;

public enum EventDirection {

	INCOMING, OUTCOMING;

}
