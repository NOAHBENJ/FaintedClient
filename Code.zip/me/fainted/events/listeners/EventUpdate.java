package me.fainted.events.listeners;

import me.fainted.events.Event;

public class EventUpdate extends Event<EventUpdate>{

}
