package me.fainted.events;

public enum EventType {

	PRE, POST;
	
}
