package me.fainted.module.render;

import me.fainted.module.Category;
import me.fainted.module.Module;

public class TargetHUD extends Module{

	public TargetHUD() {
		super("TargetHUD", 0, Category.RENDER);
	}
	
}
