package me.fainted.module.combat;

import java.util.Iterator;

import org.lwjgl.input.Keyboard;

import me.fainted.Fainted;
import me.fainted.gui.GuiIngameHook;
import me.fainted.gui.settings.Setting;
import me.fainted.module.Category;
import me.fainted.module.Module;
import me.fainted.util.Timer;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.client.gui.Gui;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;

public class KillAura extends Module{ 

	public double reach;
	private GuiIngameHook hook = new GuiIngameHook(mc);
	public Timer timer = new Timer();
	public static int height, width;
	
	public KillAura() {
		super("KillAura", Keyboard.KEY_K, Category.COMBAT);
	}
	
	@Override
    public void setup() {
        Fainted.instance.settingsManager.rSetting(new Setting("Reach", this, 3, 2, 8, true));
        reach = Fainted.instance.settingsManager.getSettingByName("Reach").getValDouble();
    }
	
	public void onEnable() {
		//Fainted.addChatMessage("Toggled KillAura");
	}
	
	  @Override
	    public void onUpdate() {
	     
	        if(!this.isToggled())
	            return;
	       
	        ScaledResolution sr = new ScaledResolution(mc);
	        for(Iterator<Entity> entities = mc.theWorld.loadedEntityList.iterator(); entities.hasNext();) {
	            Object theObject = entities.next();
	            if(theObject instanceof EntityLivingBase) {
	                EntityLivingBase entity = (EntityLivingBase) theObject;
	               
	                if(entity instanceof EntityPlayerSP) continue;
	               
	                if(mc.thePlayer.getDistanceToEntity(entity) <= reach * 1.6f) {
	                    if(entity.isEntityAlive()) {
	                    	if (mc.currentScreen != null || mc.gameSettings.showDebugInfo) {
	                            return;
	                        }
	                        height = sr.getScaledHeight();
	                        width = sr.getScaledWidth();
	                        Gui.drawRect(width - 10, 0,width, height, 0x90000000);
	                        Gui.drawRect((int)(width * 0.65), (int)(height * 0.65), (int)(width * 0.75), (int)(height * 0.75),0xffff4500);
	                    	
	                        mc.playerController.attackEntity(mc.thePlayer, entity);
	                        mc.thePlayer.swingItem();
	                        continue;
	                    }
	                }
	            }
	        }
	        
	        
	       
	        super.onUpdate();
	    }
	
	
}
