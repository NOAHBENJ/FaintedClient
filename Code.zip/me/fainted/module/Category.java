package me.fainted.module;

public enum Category {
	
	COMBAT,
	MOVEMENT,
	RENDER,
	PLAYER,
	MISC;
	
}
